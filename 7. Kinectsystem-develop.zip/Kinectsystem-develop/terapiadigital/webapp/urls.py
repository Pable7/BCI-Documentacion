from django.urls import path

from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('index', views.index, name='index'),
    path('therapist/new/', views.therapist_new, name='therapist_new'),
    path('patient/new/', views.patient_new, name='patient_new')
]