from django.db import models
from django.utils import timezone  

# Create your models here.
class Usuario(models.Model):
    correo = models.EmailField(max_length=100, null=False)
    password = models.CharField(max_length=45)
    date_created = models.DateTimeField(default=timezone.now)
    def __str__(self):
        return self.correo

class Therapy(models.Model):
    descripcion = models.CharField(max_length=500)
    date_created = models.DateTimeField(default=timezone.now)

class Patient(models.Model):
    name = models.CharField(max_length=45)
    last_name = models.CharField(max_length=500)
    birthday = models.DateTimeField()
    height = models.FloatField()
    weight = models.FloatField()
    date_created = models.DateTimeField(default=timezone.now)

class Therapist(models.Model):
    name = models.CharField(max_length=45)
    last_name = models.CharField(max_length=45)
    birthday = models.DateField()
    date_created = models.DateTimeField(default=timezone.now)

class Admin(models.Model):
    name = models.CharField(max_length=45)
    date_created = models.DateTimeField(default=timezone.now)

class Profile(models.Model):
    date_created = models.DateTimeField(default=timezone.now)
    usuario = models.ForeignKey(Usuario, models.SET_NULL, blank=True, null=True)
    patient = models.ForeignKey(Patient, models.SET_NULL, blank=True, null=True)
    therapist = models.ForeignKey(Therapist, models.SET_NULL, blank=True, null=True)
    admin = models.ForeignKey(Admin, models.SET_NULL, blank=True, null=True)
