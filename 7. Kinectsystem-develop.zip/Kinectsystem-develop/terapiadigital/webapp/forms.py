from django import forms
from webapp.models import Therapist
from django.utils import timezone 
from django.contrib.admin import widgets

class TherapistForm(forms.Form):
    name = forms.CharField(label="Nombre: ", max_length=45)
    last_name = forms.CharField(label="Apellido: ", max_length=45)
    birthday = forms.DateTimeField(input_formats=['%d/%m/%Y %H:%M'],
    widget= forms.DateTimeInput(attrs={
        'class': ' datetimepicker-input',
        'data-target': '#datetimepicker1'
    }))

class PatientForm(forms.Form):
    name = forms.CharField(label="Nombre: ", max_length=45)
    last_name = forms.CharField(label="Apellido: ", max_length=45)
    birthday = forms.DateTimeField(input_formats=['%d/%m/%Y %H:%M'],
    widget= forms.DateTimeInput(attrs={
        'class': ' datetimepicker-input',
        'data-target': '#datetimepicker1'
    }))
    height = forms.FloatField(label="Altura: ")
    weight = forms.FloatField(label="Peso: ")
    