from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.views.generic import ListView
from webapp.models import Usuario, Patient, Therapist, Therapy
from webapp.forms import TherapistForm, PatientForm
# Create your views here.
def index(request):
    return render(request, 'index.html')

def therapist_new(request):
     # if this is a POST request we need to process the form data
    if request.method == 'POST':
        # create a form instance and populate it with data from the request:
        form = TherapistForm(request.POST)
        # check whether it's valid:
        if form.is_valid():
            print(form.cleaned_data['birthday'])
            therapist = Therapist(name=form.cleaned_data['name'], last_name=form.cleaned_data['last_name'], birthday=form.cleaned_data['birthday'])
            therapist.save()
            # process the data in form.cleaned_data as required
            # ...
            # redirect to a new URL:
            return redirect('/webapp/therapist')
    # if a GET (or any other method) we'll create a blank form
    else:
        form = TherapistForm()
    return render(request, 'therapist_new.html', {'form': form})

def patient_new(request):
    if request.method == 'POST':
        # create a form instance and populate it with data from the request:
        form = PatientForm(request.POST)
        # check whether it's valid:
        if form.is_valid():
            print(form.cleaned_data)
            patient = Patient(
                name=form.cleaned_data['name'], 
                last_name=form.cleaned_data['last_name'], 
                birthday=form.cleaned_data['birthday'],
                height=form.cleaned_data['height'],
                weight=form.cleaned_data['weight']
                )
            patient.save()
            return redirect('/webapp/patient')
    # if a GET (or any other method) we'll create a blank form
    else:
        form = PatientForm()
    return render(request, 'patient_new.html', {'form': form})

class PatientList(ListView):
    model = Patient

class TherapistList(ListView):
    model = Therapist

class TherapyList(ListView):
    model = Therapy

