from django.contrib import admin
from .models import Usuario, Therapy, Patient, Therapist, Admin, Profile
# Register your models here.
admin.site.register(Usuario)
admin.site.register(Therapy)
admin.site.register(Patient)
admin.site.register(Therapist)
admin.site.register(Admin)
admin.site.register(Profile)
